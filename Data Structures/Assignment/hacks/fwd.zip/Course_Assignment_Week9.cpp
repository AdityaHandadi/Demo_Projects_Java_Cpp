//Kambam Sumanth 
//CWID : 50131405

#include<iostream>

using namespace std;
int arrayA[28] = {3, 4, 5, 5, 6, 7, 9, 8, 10, 11, 13, 14, 17, 16, 18, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30};
int arrayB[28] = {14, 5, 19, 23, 6, 29, 4, 30, 18, 22, 10, 16, 21, 3, 5, 7, 26, 18, 20, 11, 25, 17, 27, 9, 13, 24, 8, 28};
float count1 = 0, count2 = 0, count3 = 0;
bool flag;
void exch(int c[], int a, int b)

{

	int temp = c[b];

	c[b] = c[a];

	c[a] = temp;

}
void compexchange1(int c[], int a, int b)
{

	int temp = c[b];
	count2++;
	if(c[a] > temp)
	{
		c[b] = c[a];

		c[a] = temp;
	}

}
void compexchange2(int c[], int a, int b)
{
	int temp = c[b];
	count3++;
	if(c[a] > temp)
	{

		c[b] = c[a];

		c[a] = temp;

		flag = false;

	}

}
void selection(int a[], int l, int r)

{ 

	for (int i = l; i < r; i++)

    { 
		int min = i;
        for (int j = i+1; j <= r; j++) 
		{
			count1++;
			if (a[j] < a[min]) 

			{

				min = j;

			}

		}

		exch(a, i, min);

    } 

}

void insertion(int a[], int l, int r)

{ 

	int i;

    for (i = r; i > l; i--) 
	compexchange1(a, i-1, i);
	for (i = l+2; i <= r; i++)

    {
		int j = i; int v = a[i]; 
		while (v < a[j-1])

        {

			count2++;

			a[j] = a[j-1]; 

			j--; 

		}

		count2++;

        a[j] = v; 

    } 

}

void bubble(int a[], int l, int r)

{

	for (int i = l; i < r; i++)

	{

		flag = true;

        for (int j = r; j > i; j--)

		{

		compexchange2(a, j-1, j);

		}

		if(flag)

			break;

	}

}

int main()

{

	char userChoice;
	cout << "Enter your Choice A / B / C / D / E / F  "<<"\n";
	cout<<"  A	A=Selection Sort, B=Insertion Sort"<<"\n";
	cout<<"  B	A=Selection Sort, B=Bubble Sort"<<"\n";
	cout<<"  C	A=Insertion Sort, B=Selection Sort"<<"\n";
	cout<<"  D	A=Insertion Sort, B=Bubble Sort"<<"\n";
	cout<<"  E	A=Bubble Sort, B=Insertion Sort"<<"\n";
	cout<<"  F	A=Bubble Sort, B=Selection Sort"<<"\n";

	cin >> userChoice;
	if (userChoice =='a' || userChoice=='A')
	{

	    selection(arrayA, 0, 27);

		insertion(arrayB, 0, 27);

		cout << "Sorted arrays: " << "\n";;

		for(int i = 0; i < 28; i++)

			cout << arrayA[i] << " ";

		cout << "\n";;

		for(int i = 0; i < 28; i++)

			cout << arrayB[i] << " ";

		cout << "\n";;

		cout << "Number of comparisons for Selection Sort: " << count1 << "\n";;

		cout << "Number of comparisons for Insertion Sort: " << count2 << "\n";;

		cout << "The ratio of the number of Comparisons is: " << count1/count2 << "\n";;

		}
		else if (userChoice =='b' || userChoice=='B')
		{

	      selection(arrayA, 0, 27);

		  bubble(arrayB, 0, 27);

		  cout << "Sorted Arrays :  " << "\n";;

		  for(int i = 0; i < 28; i++)

			cout << arrayA[i] << " ";

		  cout << "\n";;

		  for(int i = 0; i < 28; i++)

			cout << arrayB[i] << " ";

		  cout << "\n";;

		 cout << "Number of comparisons for Selection Sort: " << count1 << "\n";;

		 cout << "Number of comparisons for Bubble Sort: " << count3 << "\n";;

		 cout << "The ratio of the number of Comparisons is: " << count1/count3 << "\n";;

		}
		else if (userChoice =='c' || userChoice=='C')
		{

	     insertion(arrayA, 0, 27);

		 selection(arrayB, 0, 27);

		 cout << "Sorted Arrays :  " << "\n";;

		 for(int i = 0; i < 28; i++)

			cout << arrayA[i] << " ";

		 cout << "\n";;

		 for(int i = 0; i < 28; i++)

			cout << arrayB[i] << " ";

		 cout << "\n";;

		 cout << "Number of comparisons for Insertion Sort: " << count2 << "\n";;

		 cout << "Number of comparisons for Selection Sort: " << count1 << "\n";;

		 cout << "The ratio of the number of Comparisons is: " << count2/count1 << "\n";;

		}
		else if (userChoice =='d' || userChoice=='D')

		{
	      insertion(arrayA, 0, 27);

		  bubble(arrayB, 0, 27);

		  cout << "Sorted arrays: " << "\n";;

		   for(int i = 0; i < 28; i++)

			cout << arrayA[i] << " ";

		  cout << "\n";;

		  for(int i = 0; i < 28; i++)

			cout << arrayB[i] << " ";

		  cout << "\n";;

		  cout << "Number of comparisons for Insertion sort: " << count2 << "\n";;

		  cout << "Number of comparisons for Bubble sort: " << count3 << "\n";;

		  cout << "The ratio of the number of Comparisons is: " << count2/count3 << "\n";;

		}
		else if (userChoice =='e' || userChoice=='E')
		{

	      insertion(arrayB, 0, 27);

		  bubble(arrayA, 0, 27);

		  cout << "Sorted arrays: " << "\n";;

		  for(int i = 0; i < 28; i++)

			cout << arrayA[i] << " ";

		  cout << "\n";;

		  for(int i = 0; i < 28; i++)

			cout << arrayB[i] << " ";

		  cout << "\n";;

		  cout << "Number of comparisons for Bubble sort: " << count3 << "\n";;

		  cout << "Number of comparisons for Insertion sort: " << count2 << "\n";;

		  cout << "The ratio of the number of Comparisons is: " << count3/count2 << "\n";;

		}
		else if (userChoice =='f' || userChoice=='F')

		{
          selection(arrayB, 0, 27);

		  bubble(arrayA, 0, 27);

		  cout << "Sorted arrays: " << "\n";;

		  for(int i = 0; i < 28; i++)

			cout << arrayA[i] << " ";

		  cout << "\n";;

		  for(int i = 0; i < 28; i++)

			cout << arrayB[i] << " ";

		  cout << "\n";;

		  cout << "Number of comparisons for Bubble sort: " << count3 << "\n";;

		  cout << "Number of comparisons for Selection sort: " << count1 << "\n";;

		  cout << "The ratio of the number of Comparisons is: " << count3/count1 << "\n";;

		}
		else
		{
			exit(0);
		}
		
	system("pause");
	return 0;

}